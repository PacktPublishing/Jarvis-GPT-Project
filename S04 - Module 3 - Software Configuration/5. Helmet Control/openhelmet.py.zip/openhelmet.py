import os
from gpiozero import LED
from time import sleep

# Set the environment variable for GPIOZERO_PIN_FACTORY
os.environ['GPIOZERO_PIN_FACTORY'] = 'rpigpio'

# Initialize the LED
helmet = LED(14)

def helmet_toggle():
    helmet.on()  # Turn the LED on
    sleep(1)  # Wait for 'on_time' seconds
    helmet.off()  # Turn the LED off
    sleep(1)  # Wait for 'off_time' seconds
    print("Toggled Helmet")


# Main loop
def main():
    while True:
        command = input("Enter command (open/close): ").lower()
        if "open" in command or "opening" in command:
            print("Opening helmet...")
            helmet_toggle()
        elif "close" in command or "closing" in command:
            print("Closing helmet...")
            helmet_toggle()
        else:
            print("Invalid command. Try again.")

if __name__ == "__main__":
    main()