import RPi.GPIO as GPIO
import threading
from speech2text import get_speech_as_text
from chat2jarvis import chat_with_jarvis
from wakeword import run_porcupine_demo_mic
from voice_gen_openai import generate_speech_from_text, interrupt_speech
import openai
import simpleaudio as sa
import time, os
#import archive.ledswitch as ledswitch
import openhelmet as ht

# ANSI escape codes for some colors
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
MAGENTA = '\033[95m'
CYAN = '\033[96m'
WHITE = '\033[97m'
RESET = '\033[0m'  # Reset the color

listening_for_wakeword = True
button_pin = 2  # Replace with the GPIO pin number connected to your button
GPIO.setmode(GPIO.BCM)
GPIO.setup(button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
os.environ['GPIOZERO_PIN_FACTORY'] = 'rpigpio'

speech_generation_in_progress = False

# Function to play a beep sound
def play_beep():
    wave_obj = sa.WaveObject.from_wave_file("beep.wav")
    play_obj = wave_obj.play()
    play_obj.wait_done()  # Wait until sound has finished playing

def wake_word_listener():
    access_key = 'insert API Here'
    current_directory = os.getcwd()
    keyword_paths = [
        os.path.join(current_directory, 'wakewordmodels', 'Hey-Jarvis_en_raspberry-pi_v3_0_0.ppn'),
        os.path.join(current_directory, 'wakewordmodels', 'Jarvis_en_raspberry-pi_v3_0_0.ppn')
    ]  
    audio_device_index = 0  # lav Mic
    run_porcupine_demo_mic(access_key, keyword_paths, audio_device_index, wake_word_callback)

# def handle_jarvis_command(response): #For LED Control
#     response_lower = response.lower()
#     if "turn on" in response_lower or "turning on" in response_lower:
#         ledswitch.turn_on_led()
#     elif "turn off" in response_lower or "turning off" in response_lower:
#         ledswitch.turn_off_led()
#     elif "toggle" in response_lower or "toggling" in response_lower:
#         ledswitch.toggle_led()
#     else:
#         pass  


def handle_jarvis_command(response): # for helmet control
    response_lower = response.lower()
    if "open" in response_lower or "opening" in response_lower or "close" in response_lower or "closing" in response_lower:
        ht.helmet_toggle()
    else:
        pass  

def process_user_interaction(get_speech_as_text_param):
    global listening_for_wakeword
    try:
        user_speech, speech_to_text_latency = get_speech_as_text(get_speech_as_text_param)

        if user_speech and not user_speech.isspace():
            if user_speech.lower() in ['quit', 'exit','nothing','never mind','standby']:
                print("Exiting conversation...")
                print("Press the button or say the wake word to start Jarvis.")
                return False  # Indicate to stop the conversation loop

            jarvis_response, chat_latency = chat_with_jarvis(user_speech) 

            print(f"{BLUE}Jarvis:", jarvis_response, f"{RESET}")
            handle_jarvis_command(jarvis_response)

            audio_gen_latency = generate_speech_from_text(jarvis_response)

          

            total_latency = speech_to_text_latency + chat_latency + audio_gen_latency
            print("============================")
            print(f"{GREEN}[[Total Latency]]: {total_latency:.3f} seconds{RESET}")
            print("============================\n")

        else:
            print("No valid input detected, please try again.")
    except Exception as e:
        print(f"Error occurred: {e}")
    finally:
        listening_for_wakeword = True
        #print("Press the button or say the wake word to start Jarvis.")
    return True

def wake_word_callback(keyword):
    global listening_for_wakeword, interrupt_event, speech_generation_in_progress
    if speech_generation_in_progress:
        interrupt_event.set()
    #play_beep()
    print("Wake word detected. Speak to Jarvis")
    if listening_for_wakeword:
        listening_for_wakeword = False  # Set to False before processing the user interaction
        continue_conversation = True
        while continue_conversation:
            play_beep()
            continue_conversation = process_user_interaction(True)
        listening_for_wakeword = True

def button_pressed_callback(channel):
    global listening_for_wakeword, interrupt_event, speech_generation_in_progress
    if speech_generation_in_progress:
        interrupt_event.set()
    play_beep()
    print("Button pressed. Speak to Jarvis")
    if listening_for_wakeword:
        listening_for_wakeword = False
        process_user_interaction(False)

# Add event detection for the button press
GPIO.add_event_detect(button_pin, GPIO.RISING, callback=button_pressed_callback, bouncetime=300)

def main():
    print("Press the button or say the wake word to start Jarvis.")
    wake_word_thread = threading.Thread(target=wake_word_listener)
    wake_word_thread.daemon = True  
    wake_word_thread.start()
    try:
        while True:
            # Main loop can perform other tasks or just wait for the button press
            pass
    except KeyboardInterrupt:
        print("Program stopped")
    finally:
        GPIO.cleanup()  # Clean up GPIO on exit


if __name__ == "__main__":
    main()
