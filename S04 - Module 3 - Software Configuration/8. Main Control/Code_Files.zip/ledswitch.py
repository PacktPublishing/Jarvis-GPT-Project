import os
from gpiozero import LED

# Set the environment variable for GPIOZERO_PIN_FACTORY
os.environ['GPIOZERO_PIN_FACTORY'] = 'rpigpio'

# Initialize the LED
led = LED(21)

def turn_on_led():
    led.on()
    print("LED is on.")

def turn_off_led():
    led.off()
    print("LED is off.")

def toggle_led():
    led.toggle()
    print("LED state toggled.")

# Main loop
def main():
    while True:
        command = input("Enter command (on/off/toggle/exit): ").lower()
        if command == "on":
            turn_on_led()
        elif command in ("off", "of"):
            turn_off_led()
        elif command == "toggle":
            toggle_led()
        elif command == "exit":
            turn_off_led()  # Ensure LED is turned off before exiting
            print("Exiting program.")
            break
        else:
            print("Invalid command. Try again.")

if __name__ == "__main__":
    main()