from pvrecorder import PvRecorder

def list_audio_devices():
    available_devices = PvRecorder.get_available_devices()
    for index, device in enumerate(available_devices):
        print(f"[{index}] {device}")

if __name__ == "__main__":
    list_audio_devices()
