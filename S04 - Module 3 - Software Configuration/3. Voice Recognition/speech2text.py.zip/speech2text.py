import RPi.GPIO as GPIO
import time

from pvrecorder import PvRecorder
import wave
import openai
import struct
import threading
import whisper

MAGENTA = '\033[95m'
RESET = '\033[0m'  # Reset the color to default

transcribed_text_global = None

def timed_record_audio_tenseconds(output_file, device_index, record_seconds=10):
    frame_length = 512
    recorder = PvRecorder(device_index=device_index, frame_length=frame_length)
    frames = []

    try:
        recorder.start()
        #print(f"Recording for {record_seconds} seconds...")

        for _ in range(int(recorder.sample_rate / frame_length * record_seconds)):
            frame = recorder.read()
            # Convert the frame data to bytes using struct
            frame_bytes = struct.pack('h' * len(frame), *frame)
            frames.append(frame_bytes)

        #print("Finished recording")

    finally:
        recorder.stop()
        recorder.delete()

    # Save the recorded frames as a WAV file
    with wave.open(output_file, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)  # Assuming 16-bit audio
        wf.setframerate(recorder.sample_rate)
        wf.writeframes(b''.join(frames))

def timed_record_audio(output_file, device_index, button_pin=2):
    frame_length = 512
    recorder = PvRecorder(device_index=device_index, frame_length=frame_length)
    frames = []

    try:
        recorder.start()
        while GPIO.input(button_pin) == GPIO.HIGH:  # Assuming a pull-up resistor
            frame = recorder.read()
            frame_bytes = struct.pack('h' * len(frame), *frame)
            frames.append(frame_bytes)
    finally:
        recorder.stop()
        recorder.delete()

    with wave.open(output_file, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(recorder.sample_rate)
        wf.writeframes(b''.join(frames))


def record_audio(stop_event, device_index):
    recorder = PvRecorder(device_index=device_index, frame_length=512)
    audio = []

    try:
        recorder.start()
        print("Recording... Press Enter in the console to stop.")
        while not stop_event.is_set():
            frame = recorder.read()
            audio.extend(frame)

    finally:
        recorder.stop()
        recorder.delete()

        with wave.open('output.wav', 'w') as f:
            f.setparams((1, 2, 16000, 512, "NONE", "NONE"))
            f.writeframes(struct.pack("h" * len(audio), *audio))

        print("Recording saved as 'output.wav'")

def wait_for_stop_command(stop_event):
    input("Press Enter to stop recording...")
    stop_event.set()

def select_microphone():
    available_devices = PvRecorder.get_available_devices()
    for index, device in enumerate(available_devices):
        #print(f"[{index}] {device}")
        pass
    logitech_mic_index = None
    for index, device in enumerate(available_devices):
        if "USB Lavalier Microphone Mono" in device:
            logitech_mic_index = index
            break

    if logitech_mic_index is None:
        raise Exception("Logitech Webcam C930e Microphone not found")
    return logitech_mic_index

def get_speech_as_text(mode):
    device_index = select_microphone()  # Ensure this function returns the correct microphone index
    if not mode:
        timed_record_audio('output.wav', device_index)
    else:
        timed_record_audio_tenseconds('output.wav', device_index)

    recording_end_time = time.time()  # Timestamp after recording is finished
    
    # Transcribe the recorded audio and store in a global variable
    global transcribed_text_global
    transcribed_text_global, transcription_latency = transcribe_audio('output.wav', recording_end_time)
    
    return transcribed_text_global, transcription_latency

def transcribe_audio(file_path, recording_end_time):
    global transcribed_text_global
    client = openai.OpenAI()
    
    transcription_start_time = time.time()# Start timing for transcription
    print("Now Transcribing Audio")
    with open(file_path, "rb") as audio_file:
        transcript = client.audio.transcriptions.create(
          model="whisper-1",
          language="en",
          file=audio_file
        )
    transcribed_text_global = transcript.text
    print(f"{MAGENTA}User: {transcript.text}{RESET}")

    transcription_latency = transcription_start_time - recording_end_time
    print(f"[Transcription Latency]: {transcription_latency:.3f} seconds")
    return transcribed_text_global, transcription_latency


# def main():
#     print("Testing speech-to-text functionality. Please speak into the microphone.")
#     transcribed_text = get_speech_as_text()
#     print(f"Transcribed Text: '{transcribed_text}'")


