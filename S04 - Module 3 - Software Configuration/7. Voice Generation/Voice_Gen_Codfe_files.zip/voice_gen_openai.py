import openai
from pydub import AudioSegment
import simpleaudio as sa
import io
import time
import re
import threading
from queue import Queue


# Function to split text into sentences
def split_text_into_sentences(text):
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text)
    return sentences

# Function to process a sentence and enqueue the audio bytes
def process_sentence(sentence, model, voice, play_queue):
    #print(f"Processing sentence: {sentence}")
    response = openai.audio.speech.create(
        model=model,
        voice=voice,
        input=sentence
    )
    audio_bytes = response.content
    play_queue.put(audio_bytes)
    #print(f"Enqueued audio for sentence: {sentence}")

# Function to play audio from the queue
def audio_player(play_queue):
    while True:
        audio_bytes = play_queue.get()
        if audio_bytes is None:
            play_queue.task_done()
            break  # Stop the thread if None is enqueued
        #print("Playing audio...")
        audio = AudioSegment.from_file(io.BytesIO(audio_bytes), format="mp3")
        playback = sa.play_buffer(
            audio.raw_data,
            num_channels=audio.channels,
            bytes_per_sample=audio.sample_width,
            sample_rate=audio.frame_rate
        )
        playback.wait_done()
        play_queue.task_done()
        #print("Audio playback finished.")

# Function to generate speech from text and play it back sentence by sentence
def generate_speech_from_text(text, model="tts-1", voice="echo"):
    start_time = time.time()  # Start the timer
    sentences = split_text_into_sentences(text)
    play_queue = Queue()
    player_thread = threading.Thread(target=audio_player, args=(play_queue,))
    player_thread.start()

    

    # Process the first sentence and enqueue it
    process_sentence(sentences[0], model, voice, play_queue)

    # Measure the latency after the first sentence is processed
    latency = time.time() - start_time
    print(f"[AudioGen Latency]: {latency:.3f} seconds")

    # Process the remaining sentences sequentially
    for sentence in sentences[1:]:
        process_sentence(sentence, model, voice, play_queue)

    play_queue.put(None)

    player_thread.join()
    #print("Audio playback finished.")

    return latency

def main():
    
    sample_text = "Certainly, sir. Allow me to elucidate the enigma that is vibranium. Vibranium, a rare and mystical metal, was bestowed upon our Earth by a celestial meteorite some 10,000 years ago. Its arrival was shrouded in cosmic mystery, and it found its earthly abode in the heart of the African nation of Wakanda. Possessing an uncanny ability to absorb, store, and then release vast amounts of kinetic energy, vibranium defies the laws of physics. Imagine a substance that can drink in the force of a speeding bullet, rendering it as harmless as a gentle breeze."
  
    for i in range(10):
        generate_speech_from_text(sample_text)

if __name__ == "__main__":
    main()
