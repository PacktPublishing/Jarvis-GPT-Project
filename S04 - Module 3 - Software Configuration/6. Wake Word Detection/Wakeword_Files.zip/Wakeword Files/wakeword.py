import subprocess
import pvporcupine
from pvrecorder import PvRecorder
import os, struct

def run_porcupine_demo_mic(access_key, keyword_paths, audio_device_index, callback):
    try:
        porcupine = pvporcupine.create(access_key=access_key, keyword_paths=keyword_paths)
        recorder = PvRecorder(device_index=audio_device_index, frame_length=porcupine.frame_length)

        recorder.start()
        print("Listening for wake word...")

        while True:
            pcm = recorder.read()
            keyword_index = porcupine.process(pcm)
            if keyword_index >= 0:
                # Wake word detected, call the callback with the keyword index
                callback(keyword_index)
                # If you want to stop listening after detection, uncomment the following line
                # break

    finally:
        recorder.stop()
        recorder.delete()
        porcupine.delete()

def callback(keyword_index):
    print(f"Wake word detected at index {keyword_index}")

def main():
    access_key = 'tXgViDUlpHuryjwRAPqSOyFplyLkD1C64+YOF8TpZu71iqsryBZORQ=='
    current_directory = os.getcwd()
    keyword_paths = [
        os.path.join(current_directory, 'wakewordmodels', 'Hey-Jarvis_en_raspberry-pi_v3_0_0.ppn'),
        os.path.join(current_directory, 'wakewordmodels', 'Jarvis_en_raspberry-pi_v3_0_0.ppn')
    ]  # Paths to your custom keyword files
    audio_device_index = 0  # Replace with the correct device index for your microphone

    run_porcupine_demo_mic(access_key, keyword_paths, audio_device_index,callback)

if __name__ == "__main__":
    main()
