from embedchain import Pipeline as App
import time

jarvis_bot = App()
jarvis_bot = App.from_config("openai.yaml")

def chat_with_jarvis(user_input):
    # Start timing
    start_time = time.time()
    response = jarvis_bot.chat(user_input)    # Process the chat input
    end_time = time.time()
    
    latency = end_time - start_time # Calculate latency
    
    # Print the latency time
    print(f"[ChatGPT Latency]: {latency:.3f} seconds")
    
    # Return the response
    return response, latency


